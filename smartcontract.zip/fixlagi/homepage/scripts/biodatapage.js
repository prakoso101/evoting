// startVoting.js

// Initialize web3
window.addEventListener("load", async () => {
    if (typeof window.ethereum !== "undefined") {
        // MetaMask is available
        const web3 = new web3(window.ethereum);
        try {
            // Request access to user's MetaMask accounts
            await window.ethereum.enable();

            // Contract address and ABI
            const contractAddress = "0x92C63763643edA634D3670172D2C3a92D2B57D73";
            const contractABI = [
                {
                    "inputs": [],
                    "stateMutability": "nonpayable",
                    "type": "constructor"
                },
                {
                    "anonymous": false,
                    "inputs": [
                        {
                            "indexed": true,
                            "internalType": "uint256",
                            "name": "nik",
                            "type": "uint256"
                        }
                    ],
                    "name": "VoterRegistered",
                    "type": "event"
                },
                {
                    "inputs": [],
                    "name": "admin",
                    "outputs": [
                        {
                            "internalType": "address",
                            "name": "",
                            "type": "address"
                        }
                    ],
                    "stateMutability": "view",
                    "type": "function"
                },
                {
                    "inputs": [
                        {
                            "internalType": "uint256",
                            "name": "",
                            "type": "uint256"
                        }
                    ],
                    "name": "voters",
                    "outputs": [
                        {
                            "internalType": "string",
                            "name": "nama",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "email",
                            "type": "string"
                        },
                        {
                            "internalType": "uint256",
                            "name": "age",
                            "type": "uint256"
                        },
                        {
                            "internalType": "uint256",
                            "name": "nik",
                            "type": "uint256"
                        },
                        {
                            "internalType": "bool",
                            "name": "registered",
                            "type": "bool"
                        }
                    ],
                    "stateMutability": "view",
                    "type": "function"
                },
                {
                    "inputs": [
                        {
                            "internalType": "address",
                            "name": "_newAdmin",
                            "type": "address"
                        }
                    ],
                    "name": "changeAdmin",
                    "outputs": [],
                    "stateMutability": "nonpayable",
                    "type": "function"
                },
                {
                    "inputs": [
                        {
                            "internalType": "string",
                            "name": "_nama",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "_email",
                            "type": "string"
                        },
                        {
                            "internalType": "uint256",
                            "name": "_age",
                            "type": "uint256"
                        },
                        {
                            "internalType": "uint256",
                            "name": "_nik",
                            "type": "uint256"
                        }
                    ],
                    "name": "registerVoter",
                    "outputs": [],
                    "stateMutability": "nonpayable",
                    "type": "function"
                },
                {
                    "inputs": [
                        {
                            "internalType": "uint256",
                            "name": "_nik",
                            "type": "uint256"
                        }
                    ],
                    "name": "getVoter",
                    "outputs": [
                        {
                            "internalType": "string",
                            "name": "",
                            "type": "string"
                        },
                        {
                            "internalType": "string",
                            "name": "",
                            "type": "string"
                        },
                        {
                            "internalType": "uint256",
                            "name": "",
                            "type": "uint256"
                        },
                        {
                            "internalType": "bool",
                            "name": "",
                            "type": "bool"
                        }
                    ],
                    "stateMutability": "view",
                    "type": "function"
                }
            ];

            // You can now interact with the contract
            const contract = new web3.eth.Contract(contractABI, contractAddress);

            // Form submission event handler
            document.getElementById('biodataForm').addEventListener('submit', async (event) => {
                event.preventDefault();

                // Get form inputs
                const nama = event.target.elements.name.value;
                const email = event.target.elements.email.value;
                const age = event.target.elements.age.value;
                const nik = event.target.elements.nik.value;

                try {
                    // Send a transaction to the contract function registerVoter
                    const accounts = await web3.eth.getAccounts();
                    const tx = await contract.methods.registerVoter(nama, email, age, nik).send({ from: accounts[0] });

                    // Transaction receipt
                    console.log(tx);

                    // Reset form inputs
                    event.target.reset();

                    // Redirect user to another page (optional)
                    window.location.href = "votingpage.php";

                } catch (error) {
                    console.error(error);
                }
            });

        } catch (error) {
            console.error("User denied account access or error occurred", error);
        }
    } else {
        console.log("MetaMask is not available");
    }
});
