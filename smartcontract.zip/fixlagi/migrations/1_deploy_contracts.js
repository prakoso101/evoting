const Voting = artifacts.require("VoterRegistry");

module.exports = function (deployer) {
    deployer.deploy(Voting);
};